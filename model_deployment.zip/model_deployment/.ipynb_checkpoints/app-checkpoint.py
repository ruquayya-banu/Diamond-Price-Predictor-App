import streamlit as st
import pandas as pd
import pickle


#--------------Page configuration-------

st.set_page_config(page_title="Diamond Price Predictor", layout="centered")




#----------Load trained pipeline---------


@st.cache_resource

def load_model():
    with open("diamond_price_prediction.pkl","rb") as f:
        return pickle.load(f)


model=load_model()


# ------- App title----------
st.title("💎 Diamond Price predictor app")
st.write("Predict diamond price using trained ML model")



# ------User inputs--------

carat=st.number_input("Carat",min_value=0.1,max_value=5.0,value=0.7)
cut=st.selectbox("Cut",["Fair","Good","Veru Good","Premium","Ideal"])
color=st.selectbox("Color",["D","E","F","I","J"])
clarity=st.selectbox("Clarity",["I1","SI2","SI1","VS2","VS1","VVS2","VVS1","IF"])
depth=st.number_input("depth",value=61.5)
table=st.number_input("Table",value=55.0)
x=st.number_input("X length in mm",value=5.7)
y=st.number_input("Y length in mm",value=5.7)
z=st.number_input("Z length in mm",value=5.7)


#-----Prediction-----------


if st.button("Predict price 💸"):
    input_df=pd.DataFrame([{
        "carat":carat,
        "cut":cut,
        "color":color,
        "clarity":clarity,
        "depth":depth,
        "table":table,
        "x":x,
        "y":y,
        "z":z}])


    prediction=model.predict(input_df)[0]
    st.success(f"Estimated Diamond price is:{round(prediction,2)}")












